package com.qy.dch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DchApplication {

	public static void main(String[] args) {
		SpringApplication.run(DchApplication.class, args);
	}

}
