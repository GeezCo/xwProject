package com.qy.dch.service;


import com.qy.dch.dto.OriginTextDTO;
import com.qy.dch.dto.TextTypeDTO;
import com.qy.dch.request.GetListRequest;

import java.util.List;

public interface UygurService {

    void savetext();

    List<TextTypeDTO> getCategory();

    List<OriginTextDTO> getTextList(GetListRequest getListRequest);
}
