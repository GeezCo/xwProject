package com.qy.dch.service;


public interface MainService {
    void fourDimension();
    void fourDimensionPara(String name, String prompt, String filename);

    String monitorPage();

}
