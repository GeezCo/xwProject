package com.qy.dch.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonitorWorkerVO {

    private String gpuOccupancy;

    private String videoMemoryOccupancy;

    private String temperature;

    private String productBrand;

    private String productName;
}
