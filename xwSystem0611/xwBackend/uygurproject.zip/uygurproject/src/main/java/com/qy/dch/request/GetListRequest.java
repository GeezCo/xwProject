package com.qy.dch.request;

import lombok.Data;

@Data
public class GetListRequest {
    private int pageNum;

    private int pageSize;

    private Integer typeId;

}
