package com.qy.dch.controller;

import org.json.JSONObject;
import org.json.XML;
import com.jcraft.jsch.*;
import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class JschCommand {

    private static String exeCommand(String host, int port, String user, String password, String command) throws JSchException, IOException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, host, port);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(password);
        session.connect();

        ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
        InputStream in = channelExec.getInputStream();
        channelExec.setCommand(command);
        channelExec.setErrStream(System.err);
        channelExec.connect();
        String out = IOUtils.toString(in, "UTF-8");
        channelExec.disconnect();
        session.disconnect();
        return out;
    }

    public static void main(String[] args) {
        String host = "223.0.30.25";
        int port = (int) (22);
        String user = "yinbanghu";
        String password = "tieshu34";
        String command = "nvidia-smi -q -x";
        String res = "";
        try {
            res = exeCommand(host, port, user, password, command);
            System.out.println(res);
        } catch (Exception e) {
            System.out.println("运行报错,详情：" + e);
        }

        JSONObject xmlJSONObj = XML.toJSONObject(res);
        System.out.println(xmlJSONObj.toString());

    }

}