package com.qy.dch.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author dch
 * @create 2024-07-27 23:11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageDomain {

	private Integer total;

	private List list;

	private Integer pageNum;

	private Integer pageSize;

	private Integer pages;

}
