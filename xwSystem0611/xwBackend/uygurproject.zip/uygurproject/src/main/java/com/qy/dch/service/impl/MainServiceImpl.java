package com.qy.dch.service.impl;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;
import com.qy.dch.service.LlmSercice;
import com.qy.dch.service.MainService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;

@Slf4j
@Service
public class MainServiceImpl implements MainService {

    @Autowired
    LlmSercice llmSercice;

    @Override
    public void fourDimension() {
        StringBuilder stringBuilder = new StringBuilder();
        try (FileInputStream fis = new FileInputStream("F:\\启元\\崔老师\\楚涵\\60W字0000\\网安动态01-35.docx");
             XWPFDocument document = new XWPFDocument(fis)) {

            // 读取文档中的所有段落
            for (XWPFParagraph paragraph : document.getParagraphs()) {
                stringBuilder.append(paragraph.getText());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println();
        String string = stringBuilder.toString();
        String[] articles = string.split("（全文完）");

        for (int i = 0; i < articles.length-1; i++) {
            String ans = llmSercice.generateAnswerByQwen72B(articles[i]+" 帮我输出其中包含政治类的文字，首先输出【】中的标题，其次以政策演变、政治联盟、监管治理等为主题为标题，一个主题一段，用自然语言的文字进行三到四段输出。", 5);
            ans = ans.replaceAll("\\*","").replaceAll(" #","").replaceAll("#","");
            exportReportWord(ans,"F:\\启元\\崔老师\\楚涵\\4维度\\政治.docx");
            System.out.println(ans);
        }
        return ;
    }

    @Override
    public void fourDimensionPara(String name, String prompt, String filename) {

        for (int i = 0; i < 500; i++) {
            String ans = llmSercice.generateAnswerByQwen32B("始终站在大陆视角，\n" +
                    "参考大陆“2022年台海联合”、“联合利剑2024”、“海峡雷霆2025A”等军事演习消息内容，\n" +
                    "立足将来台海局势紧张，围绕封锁台湾本岛军事行动，\n" +
                    "注重运用谋略，\n" +
                    "主要针对美国政府高层关于台湾的支援“台独”，可能介入台海，生成5条舆论战、心理战行动。\n" +
                    "每个行动包括1.主题（详细到30字左右），2.目的（详细到30字左右），3.行动要点（详细一点，50字左右），4.受众对象，行动针对的目的国家或地区（20字左右），比如台湾或美国等，5.投送渠道，也就是行动路径，可以是网络，也可以是具体路径（20字左右）。", 5);
            ans = ans.substring(ans.indexOf("</think>")+8,ans.length());
            ans = ans.replaceAll("\\*","").replaceAll(" #","").replaceAll("#","");
            exportReportWord(ans,"F:\\启元\\崔老师\\楚涵\\4维度\\策略集\\"+name+".docx");
            System.out.println(ans);
        }
        return ;
    }

    @Override
    public String monitorPage() {

        String hostname = "223.0.30.25";
        String username = "yinbanghu";
        String password = "tieshu34";

        try {
            Connection conn = new Connection(hostname);
            conn.connect();
            boolean isAuthenticated = conn.authenticateWithPassword(username, password);
            if (!isAuthenticated) {
                throw new IOException("Authentication failed");
            }
            Session sess = conn.openSession();

            // 命令语句,必须使用绝对路径否则无效(环境变量也不可以)。如：java --version
            sess.execCommand("pwd");

            InputStream stdout = new StreamGobbler(sess.getStdout());
            BufferedReader br = new BufferedReader(new InputStreamReader(stdout));
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }

                // 输出命令执行结果
                System.out.println(line);
            }
            sess.close();
            conn.close();
        } catch (IOException e) {
            e.printStackTrace(System.err);
            System.exit(2);
        }

        return "";
    }

    public void fourDimensionParaBak(String name, String prompt, String filename) {
        StringBuilder stringBuilder = new StringBuilder();
        try (FileInputStream fis = new FileInputStream("F:\\启元\\崔老师\\楚涵\\60W字0000\\"+filename+".docx");
             XWPFDocument document = new XWPFDocument(fis)) {

            // 读取文档中的所有段落
            for (XWPFParagraph paragraph : document.getParagraphs()) {
                stringBuilder.append(paragraph.getText());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println();
        String string = stringBuilder.toString();
        String[] articles = string.split("（全文完）");

        for (int i = 0; i < articles.length-1; i++) {
            String ans = llmSercice.generateAnswerByQwen32B(articles[i]+" "+prompt, 5);
            ans = ans.substring(ans.indexOf("</think>")+8,ans.length());
            ans = ans.replaceAll("\\*","").replaceAll(" #","").replaceAll("#","");
            exportReportWord(ans,"F:\\启元\\崔老师\\楚涵\\4维度\\策略集\\"+name+".docx");
            System.out.println(ans);
        }
        return ;
    }


    public void exportReportWord(String content, String outputPath) {
        try {
            // 打开已存在的Word文档
            File docFile = new File(outputPath);
            FileInputStream fis = new FileInputStream(docFile);
            XWPFDocument doc = new XWPFDocument(fis);
            fis.close();

            // 在文档末尾添加新的一页和内容
            XWPFParagraph newParagraph = doc.createParagraph(); // 创建新段落以开始新的一页（通常不需要额外代码，因为段落会自动分页）
            XWPFRun newRun = newParagraph.createRun();
            newRun.addBreak(BreakType.PAGE); // 添加分页符以确保新内容开始于新页
            newRun.setText(content);
            newRun.setFontSize(11);
            newRun.setColor("000000");
            newRun.setFontFamily("宋体");

            // 需要替换的文本
            String text = newRun.getText(0);

            //            newRun.setText(content);
            // 在原先文本中获取存在"\n"的段落
            if (text.indexOf("\n") != -1) {
                // 清空原先文本，使用换行后的新文本
                newRun.setText("", 0);
                String[] split = text.split("\n");
                // 进行换行和缩进
                if (split != null && split.length > 0) {
                    for (int i = 0; i < split.length; i++) {
                        newRun.setText(split[i]);
                        if (i < (split.length - 1)) {
                            // 实现换行
                            newRun.addBreak();
                            // 实现缩进
                            // r.addTab();
                        }
                    }
                }
            }

            // 写入到文件系统，覆盖原文件或保存为新文件（根据需要选择）
            FileOutputStream out = new FileOutputStream(outputPath); // 可选择覆盖原文件或另存为新文件
            doc.write(out);
            out.close();
            doc.close();
            System.out.println("Word文档更新成功！");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void exportReportWordBak(String content, String outputPath) {
        // 新建文件
        XWPFDocument document = new XWPFDocument();

        // 创建段落
        XWPFParagraph paragraph = document.createParagraph();
        paragraph.setAlignment(ParagraphAlignment.LEFT);
        XWPFRun r = paragraph.createRun();
        r.setText(content);
        r.setFontSize(11);
        r.setColor("000000");
        r.setFontFamily("宋体");

        // 需要替换的文本
        String text = r.getText(0);
        // 在原先文本中获取存在"\n"的段落
        if (text.indexOf("\n") != -1) {
            // 清空原先文本，使用换行后的新文本
            r.setText("", 0);
            String[] split = text.split("\n");
            // 进行换行和缩进
            if (split != null && split.length > 0) {
                for (int i = 0; i < split.length; i++) {
                    r.setText(split[i]);
                    if (i < (split.length - 1)) {
                        // 实现换行
                        r.addBreak();
                        // 实现缩进
                        // r.addTab();
                    }
                }
            }
        }

        try {
            System.out.println(outputPath);
            PoiWordUtil.saveDocument(document, outputPath);
        }
        catch (IOException e) {
            log.error("生成word失败：{}", e.getMessage());
            throw new RuntimeException(e);
        }

    }

}
