package com.qy.dch.service;

public interface LlmSercice {

    public String generateAnswerByQwen72B(String content1, int retryTime);

    public String generateAnswerByQwen32B(String content1, int retryTime);

}