package com.qy.dch.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OriginTextDTO {
    private Integer sid;
    private String title;
    private String content;
    private String times;
    private Integer type;
}
