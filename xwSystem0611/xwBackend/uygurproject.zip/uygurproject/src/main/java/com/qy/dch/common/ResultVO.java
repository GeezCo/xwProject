package com.qy.dch.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultVO {

    private Integer code;

    private Object data;

    private String msg;

    private Object flag;

    // 增删改 成功响应
    public static ResultVO success() {
        return new ResultVO(1, null, "success", "true");
    }

    // 查询 成功响应
    public static ResultVO success(Object data) {
        return new ResultVO(1, data, "success", "true");
    }

    // 失败响应
    public static ResultVO error(String msg) {
        return new ResultVO(0, null, msg, "false");
    }

}