package com.qy.dch.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonitorGpuVO {

    private String name;

    private String ip;

    private List<MonitorWorkerVO> gpus;

    private String cudaVersion;

    private Integer attachedGpus;

    private String driverVersion;

    private List<String> tags;

    private String cpuOccupancy;

    private String memoryOccupancy;

    private String diskOccupancy;

    private Integer status;

}
