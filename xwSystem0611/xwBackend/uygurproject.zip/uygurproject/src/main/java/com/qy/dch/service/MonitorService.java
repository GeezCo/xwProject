package com.qy.dch.service;

import com.qy.dch.common.MonitorGpuVO;

import java.util.List;

public interface MonitorService {

    List<MonitorGpuVO> monitorGpus();

}
