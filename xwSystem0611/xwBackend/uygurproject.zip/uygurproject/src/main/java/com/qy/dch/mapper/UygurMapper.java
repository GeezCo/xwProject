package com.qy.dch.mapper;


import com.qy.dch.dto.TextTypeDTO;
import com.qy.dch.dto.OriginTextDTO;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UygurMapper {

    @Insert("INSERT INTO `uygur_project`.`origin_text` (`title`, `content`, `times`) " +
            "VALUES (#{title}, #{content}, #{times})")
    void insertOriginText(OriginTextDTO originTextDTO);


    @Select("select * from text_type")
    List<TextTypeDTO> getCategories();

    @Select("select * from origin_text where type = #{type} order by sid")
    List<OriginTextDTO> getTextListByType(Integer type);

    @Select("select * from origin_text order by sid")
    List<OriginTextDTO> getTextListAll();

}
