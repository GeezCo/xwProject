package com.qy.dch.controller;

import com.qy.dch.common.MonitorGpuVO;
import com.qy.dch.common.ResultVO;
import com.qy.dch.service.MonitorService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/monitor")
@Slf4j
public class MonitorController {

    @Autowired
    private MonitorService monitorService;

    @GetMapping("/workers")
    public ResultVO keyAccountDoc(HttpServletResponse response) {
        log.info("monitor-workers");

        List<MonitorGpuVO> monitorGpuVOs = monitorService.monitorGpus();

        ResultVO resultVO = ResultVO.success(monitorGpuVOs);
        return resultVO;
    }
}
