package com.qy.dch.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.qy.dch.dto.TextTypeDTO;
import com.qy.dch.dto.OriginTextDTO;
import com.qy.dch.mapper.UygurMapper;
import com.qy.dch.request.GetListRequest;
import com.qy.dch.service.UygurService;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class UygurServiceImpl implements UygurService {

    @Resource
    private UygurMapper uygurMapper;

    @Value("${filePath}")
    private String filePath; // 注入结果为 18

    @Override
    public void savetext() {

        try {
            //读取文件内容为字符串
//            String jsonContent = new String(Files.readAllBytes(Paths.get("F:\\启元\\新疆\\all_text_time.json")));

            String jsonContent = new String(Files.readAllBytes(Paths.get(filePath)));

            JSONArray jsonArray = JSON.parseArray(jsonContent);

            for (int i = 0; i < jsonArray.size(); i++) {
                System.out.println((i + 1) + "/" + jsonArray.size());
                OriginTextDTO originTextDTO = new OriginTextDTO();
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                originTextDTO.setTitle((String) jsonObject.get("title"));
                originTextDTO.setContent((String) jsonObject.get("content"));

                JSONArray times = (JSONArray) jsonObject.get("times");
                StringBuilder stringBuilder = new StringBuilder();
                for (int j = 0; j < times.size(); j++) {
                    if (j != 0)
                        stringBuilder.append(",");
                    stringBuilder.append(times.get(j).toString());
                }
                originTextDTO.setTimes(stringBuilder.toString());
                uygurMapper.insertOriginText(originTextDTO);
            }

        } catch (IOException e) {
            System.err.println("文件读取失败：" + e.getMessage());
        } catch (Exception e) {
            System.err.println("JSON解析失败：" + e.getMessage());
        }

    }

    @Override
    public List<TextTypeDTO> getCategory() {
        List<TextTypeDTO> textTypeDTOS = uygurMapper.getCategories();
        return textTypeDTOS;
    }

    @Override
    public List<OriginTextDTO> getTextList(GetListRequest getListRequest) {
        List<OriginTextDTO> list = new ArrayList<>();
        if(getListRequest.getTypeId() != null)
            list = uygurMapper.getTextListByType(getListRequest.getTypeId());
        else
            list = uygurMapper.getTextListAll();

        return list;
    }
}
