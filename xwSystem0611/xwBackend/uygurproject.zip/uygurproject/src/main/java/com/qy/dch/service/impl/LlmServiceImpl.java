package com.qy.dch.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.qy.dch.service.LlmSercice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@Slf4j
@Service
public class LlmServiceImpl implements LlmSercice {

    @Value("http://223.0.30.25:1888/v1/chat/completions")
    private String llmUrlQwen72b;


    @Value("5")
    private int llmRetryTimeQwen;

    public String generateAnswerByQwen72B(String content1, int retryTime) {

        JSONObject requestBody = new JSONObject();
        JSONArray messages = new JSONArray();
        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", content1);
        messages.add(message);
        requestBody.put("messages", messages);
        requestBody.put("model", "qwen-72b-chat");
        requestBody.put("stream", true);
        requestBody.put("temperature", 0.85);
        requestBody.put("top_p", 0.8);

        String questionBody = requestBody.toString();
        StringBuilder content = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(llmUrlQwen72b);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            conn.setRequestProperty("Authorization", "Bearer " + "sk-qiyuan");
            OutputStream os = conn.getOutputStream();
            byte[] input = questionBody.getBytes("utf-8");
            os.write(input, 0, input.length);
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine != null && !inputLine.isEmpty() && inputLine.contains("content")) {
                    if (inputLine.contains("data: ")) {
                        inputLine = inputLine.substring("data: ".length());
                    }
                    JSONObject jsonObject = JSONObject.parseObject(inputLine);
                    JSONObject choice = (JSONObject) jsonObject.getJSONArray("choices").get(0);
                    String contentAns = choice.getJSONObject("delta").getString("content");
                    content.append(contentAns);
                }
            }
            in.close();
        } catch (Exception e) {
            if (retryTime < llmRetryTimeQwen) {
                try {
                    Thread.sleep(1000 * 10);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                log.error("大模型访问异常，原因为{}, 第{}次重试！", e.getMessage(), retryTime + 1);
                return generateAnswerByQwen72B(questionBody, retryTime + 1);
            } else {
                log.error("大模型访问异常，原因为{}, 已达到最大重试次数！", e.getMessage());
            }
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        if (content.toString().isEmpty()) {
            if (retryTime < llmRetryTimeQwen) {
                try {
                    Thread.sleep(1000 * 10);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                log.error("大模型访问异常，返回结果为null, 第{}次重试！", retryTime + 1);
                return generateAnswerByQwen72B(questionBody, retryTime + 1);
            } else {
                log.error("大模型访问异常，返回结果为null, 已达到最大重试次数！");
            }

        } else {
            return content.toString();
        }
        return content.toString();
    }

    @Override
    public String generateAnswerByQwen32B(String content1, int retryTime) {

        JSONObject requestBody = new JSONObject();
        JSONArray messages = new JSONArray();
        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", content1);
        messages.add(message);
        requestBody.put("messages", messages);
        requestBody.put("model", "qwen-qwq-32b");
        requestBody.put("stream", true);
        requestBody.put("temperature", 0.85);
        requestBody.put("top_p", 0.8);

        String questionBody = requestBody.toString();
        StringBuilder content = new StringBuilder();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(llmUrlQwen72b);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            conn.setRequestProperty("Authorization", "Bearer " + "sk-qiyuan");
            OutputStream os = conn.getOutputStream();
            byte[] input = questionBody.getBytes("utf-8");
            os.write(input, 0, input.length);
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine != null && !inputLine.isEmpty() && inputLine.contains("content")) {
                    if (inputLine.contains("data: ")) {
                        inputLine = inputLine.substring("data: ".length());
                    }
                    JSONObject jsonObject = JSONObject.parseObject(inputLine);
                    JSONObject choice = (JSONObject) jsonObject.getJSONArray("choices").get(0);
                    String contentAns = choice.getJSONObject("delta").getString("content");
                    content.append(contentAns);
                }
            }
            in.close();
        } catch (Exception e) {
            if (retryTime < llmRetryTimeQwen) {
                try {
                    Thread.sleep(1000 * 10);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                log.error("大模型访问异常，原因为{}, 第{}次重试！", e.getMessage(), retryTime + 1);
                return generateAnswerByQwen72B(questionBody, retryTime + 1);
            } else {
                log.error("大模型访问异常，原因为{}, 已达到最大重试次数！", e.getMessage());
            }
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        if (content.toString().isEmpty()) {
            if (retryTime < llmRetryTimeQwen) {
                try {
                    Thread.sleep(1000 * 10);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                log.error("大模型访问异常，返回结果为null, 第{}次重试！", retryTime + 1);
                return generateAnswerByQwen72B(questionBody, retryTime + 1);
            } else {
                log.error("大模型访问异常，返回结果为null, 已达到最大重试次数！");
            }

        } else {
            return content.toString();
        }
        return content.toString();
    }
}
