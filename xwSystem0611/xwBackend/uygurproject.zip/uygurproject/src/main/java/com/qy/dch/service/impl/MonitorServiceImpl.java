package com.qy.dch.service.impl;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.qy.dch.common.MonitorGpuVO;
import com.qy.dch.common.MonitorWorkerVO;
import com.qy.dch.service.MonitorService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class MonitorServiceImpl implements MonitorService {

    @Override
    public List<MonitorGpuVO> monitorGpus() {

        List<MonitorGpuVO> monitorGpuVOList = new ArrayList<>();

        MonitorGpuVO monitorGpuVO = new MonitorGpuVO();
        String response = "";

        //基本属性
        monitorGpuVO.setIp("223.0.30.25");
        monitorGpuVO.setName("gpu_25");
        monitorGpuVO.setTags(Arrays.asList("os:linux","arch:amd64","worker-name:gpu_25"));

        try {
            //gpu
            response = shellExec("nvidia-smi -q -x");
            JSONObject xmlJSONObj = XML.toJSONObject(response);
            JSONObject nvidiaSmiLog = (JSONObject) xmlJSONObj.get("nvidia_smi_log");
            monitorGpuVO.setCudaVersion(String.valueOf(nvidiaSmiLog.get("cuda_version")));
            monitorGpuVO.setAttachedGpus((Integer) nvidiaSmiLog.get("attached_gpus"));
            monitorGpuVO.setDriverVersion((String) nvidiaSmiLog.get("driver_version"));
            JSONArray gpu = (JSONArray) nvidiaSmiLog.get("gpu");

            List<MonitorWorkerVO> monitorWorkerVOS = new ArrayList<>();
            for (int i = 0; i < gpu.length(); i++) {
                MonitorWorkerVO monitorWorkerVO = new MonitorWorkerVO();

                monitorWorkerVO.setGpuOccupancy(((String) ((JSONObject)((JSONObject)gpu.get(i)).get("utilization")).get("gpu_util")).replaceAll(" %",""));

                monitorWorkerVO.setTemperature(((String) ((JSONObject)((JSONObject)gpu.get(i)).get("temperature")).get("gpu_temp")).replaceAll(" C",""));

                monitorWorkerVO.setProductBrand((String) ((JSONObject)gpu.get(i)).get("product_brand"));

                monitorWorkerVO.setProductName((String) ((JSONObject)gpu.get(i)).get("product_name"));

                JSONObject fb_memory_usage = (JSONObject) ((JSONObject) gpu.get(i)).get("fb_memory_usage");
                Double total = Double.valueOf(((String) fb_memory_usage.get("total")).replaceAll("MiB","").replaceAll(" ",""));
                Double free = Double.valueOf(((String) fb_memory_usage.get("free")).replaceAll("MiB","").replaceAll(" ",""));
                monitorWorkerVO.setVideoMemoryOccupancy(String.valueOf((1-free/total) * 100));
                monitorWorkerVOS.add(monitorWorkerVO);

            }

            monitorGpuVO.setGpus(monitorWorkerVOS);

            //cpu
//        response = shellExec("awk 'NR==3 {print 100-$15\"%\"}' <(vmstat 1 2)").replaceAll("\\n","");
            response = shellExec("awk 'NR==3 {print 100-$15}' <(vmstat 1 2)").replaceAll("\\n","");
            monitorGpuVO.setCpuOccupancy(response);

            //memory
//        response = shellExec("free -h | awk '/^Mem/{total=$2; used=$3; avail=$7; print (total-avail)/total*100 \"%\"}'").replaceAll("\\n","");
            response = shellExec("free -h | awk '/^Mem/{total=$2; used=$3; avail=$7; print (total-avail)/total*100 }'").replaceAll("\\n","");
            monitorGpuVO.setMemoryOccupancy(response);

            //disk
//        response = shellExec("df --total -x tmpfs -x devtmpfs -x overlay | awk '/total/{gsub(\"%\",\"%\",$5); print $5}'").replaceAll("\\n","");
            response = shellExec("df --total -x tmpfs -x devtmpfs -x overlay | awk '/total/{gsub(\"%\",\"\",$5); print $5}'").replaceAll("\\n","");
            monitorGpuVO.setDiskOccupancy(response);

            monitorGpuVO.setStatus(1);
        } catch (Exception e) {
            monitorGpuVO.setStatus(0);
            e.printStackTrace();
        }
        monitorGpuVOList.add(monitorGpuVO);
        return monitorGpuVOList;
    }

    private String shellExec(String command){
        String host = "223.0.30.25";
//        String host = "223.0.15.45";
        int port = (int) (22);
        String user = "yinbanghu";
        String password = "tieshu34";
//        String command = "nvidia-smi -q -x";
        String res = "";
        try {
            res = exeCommand(host, port, user, password, command);
//            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("运行报错,详情：" + e);
        }

//        JSONObject xmlJSONObj = XML.toJSONObject(res);
//        System.out.println(xmlJSONObj.toString());
        return res;
    }


    private static String exeCommand(String host, int port, String user, String password, String command) throws JSchException, IOException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, host, port);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setPassword(password);
        session.connect();

        ChannelExec channelExec = (ChannelExec) session.openChannel("exec");
        InputStream in = channelExec.getInputStream();
        channelExec.setCommand(command);
        channelExec.setErrStream(System.err);
        channelExec.connect();
        String out = IOUtils.toString(in, "UTF-8");
        channelExec.disconnect();
        session.disconnect();
        return out;
    }

}
