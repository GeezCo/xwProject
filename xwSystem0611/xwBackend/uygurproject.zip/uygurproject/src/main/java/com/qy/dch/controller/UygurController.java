package com.qy.dch.controller;

import com.qy.dch.dto.OriginTextDTO;
import com.qy.dch.dto.TextTypeDTO;
import com.qy.dch.common.ResultVO;
import com.qy.dch.domain.PageDomain;
import com.qy.dch.request.GetListRequest;
import com.qy.dch.service.UygurService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/uygur")
@Slf4j
public class UygurController {

    @Autowired
    UygurService uygurService;

    @GetMapping("/savetext")
    public void keyAccountDoc() {
        log.info("savetext");
        uygurService.savetext();
    }

    @GetMapping("/category")
    public ResultVO getCategory() {
        log.info("category");
        List<TextTypeDTO> textTypeDTOS = uygurService.getCategory();
        ResultVO resultVO = ResultVO.success(textTypeDTOS);
        return resultVO;
    }

    @PostMapping("/getTextList")
    public ResultVO getList(@RequestBody GetListRequest getListRequest) {
        Integer pageNum = getListRequest.getPageNum();
        Integer pageSize = getListRequest.getPageSize();
        Integer type = getListRequest.getTypeId();
        log.info("getTextList");
        List<OriginTextDTO> list = uygurService.getTextList(getListRequest);

        PageDomain pageDomain = new PageDomain();
        Integer pages = list.size() / pageSize + 1;
        pageDomain.setPages(pages);
        pageDomain.setPageNum(pageNum);
        pageDomain.setPageSize(pageSize);
        pageDomain.setTotal(list.size());
        List<OriginTextDTO> shows = new ArrayList<>();
        if (pageNum <= pages) {
            for (int x = (pageNum - 1) * pageSize; x < pageNum * pageSize; x++) {
                if (x >= 0 && x < list.size()) {
                    shows.add(list.get(x));
                }
            }
        }
        pageDomain.setList(shows);

        ResultVO resultVO = ResultVO.success(pageDomain);
        return resultVO;
    }

}
