package com.qy.dch.controller;

import com.qy.dch.service.MainService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/project")
@Slf4j
public class MainController {

    @Autowired
    MainService mainService;

    @GetMapping("/fourDimension")
    public void keyAccountDoc(@RequestBody Map<String, Object> map, HttpServletResponse response) {
        log.info("fourDimension");
        mainService.fourDimensionPara((String) map.get("name"), (String) map.get("prompt"),(String) map.get("filename"));
    }

    @PostMapping("/resource")
    public String resourceMonitor() {
        mainService.monitorPage();
        return "";
    }

}
